const popup = document.querySelector(".hide1");
let i=0;

function popupfun(){
  document.querySelector('.hide1').classList.remove('hidden1');
  document.querySelector('.hide1').classList.add('showing');
}

function unpopupfun(){
  document.querySelector('.hide1').classList.remove('showing');
  document.querySelector('.hide1').classList.add('hidden1');
}

function mainfn(){
  i++;
  if(i%2 === 0){
    unpopupfun();
  }
  else{
    popupfun();
  }
}